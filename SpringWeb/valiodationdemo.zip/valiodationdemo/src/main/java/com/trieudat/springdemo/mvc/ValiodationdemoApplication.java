package com.trieudat.springdemo.mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValiodationdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValiodationdemoApplication.class, args);
	}

}
