package model;

public enum TransactionType {
    WITHDRAW, TRANSFER
}
